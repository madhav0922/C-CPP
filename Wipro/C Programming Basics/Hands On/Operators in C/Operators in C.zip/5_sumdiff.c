#include<stdio.h>
int main()
    {
        int a,b;
        printf("Enter two numbers\n");
        scanf("%d%d",&a,&b);
        printf("Sum of the two numbers is %d\n",a+b);
        printf("Difference of the two numbers is %d\n",a-b);
        return 0;
    }