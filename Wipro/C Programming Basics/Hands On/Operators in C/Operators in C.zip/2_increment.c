#include<stdio.h>
int main()
    {
        int i;
        printf("Enter a number\n");
        scanf("%d",&i);
        i++;
        printf("%d\n",i);
        return 0;
    }