#include<stdio.h>
int main()
    {
        int a,b,c;
        printf("Enter 3 integer numbers\n");
        scanf("%d%d%d",&a,&b,&c);
        printf("%d %d %d",a,b,c);
        return 0;
    }