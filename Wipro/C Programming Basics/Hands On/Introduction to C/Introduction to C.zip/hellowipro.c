#include<stdio.h>
int main()
    {
        printf("Welcome to Wipro\n");
        return 0;
    }