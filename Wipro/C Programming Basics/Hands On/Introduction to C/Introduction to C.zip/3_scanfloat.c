#include<stdio.h>
int main()
    {
        float a,b,c;
        printf("Enter 3 float numbers\n");
        scanf("%f%f%f",&a,&b,&c);
        printf("%f %f %f\n",a,b,c);
        return 0;
    }